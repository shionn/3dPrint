                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:2135840
SSD 2.5" Mounting Plate by RunnerPack is licensed under the Creative Commons - Attribution - Non-Commercial - Share Alike license.
http://creativecommons.org/licenses/by-nc-sa/3.0/

# Summary

**WARNING! ////// WARNING! ////// WARNING! ////// WARNING!**
I don't recommend printing this as-is. Even if you have the drive and adapter this was designed for (which is unlikely), it probably won't fit in most drive bays. If you **don't** have the same drive/adapter, it *definitely* won't work (unless you're, e.g., using it in a desktop PC with a 2.5"->3.5" mounting bracket).
**WARNING! ////// WARNING! ////// WARNING! ////// WARNING!**

I needed to mount a Samsung MMCRE28GTDX SSD (and its microSATA->SATA adapter) in my new laptop. I couldn't find anything suitable already on the 'verse, so here it is :)

My plan is to press M3 threaded inserts into the mounting holes to accept standard laptop HDD screws.

Printing is in progress; I'll update with a photo when (if?) it prints.

EDIT: Print failed :/

EDIT 2: I was able to *sort of* print it (it's badly warped, but I was able to force it into the drive caddy). I stopped the print when the brass insert holes were about half done, then used a "3d pen" to finish them with the inserts in place. I was attempting to attach the SSD to the tray with said pen when it self-destructed, so now I can't finish it. It's just as well since the SSD + converter seems too long to go into the computer (while attached to the caddy), anyway. I may get a shorter uSATA converter and redesign the plate. I may also switch to PLA, which doesn't warp as badly.

# Print Settings

Printer: M3D Micro
Rafts: Doesn't Matter
Supports: No
Resolution: Lowest
Infill: None (thick walls)

Notes: 
Why is the Micro *still* not in the list of printers?

# Post-Printing

## Threaded Holes

I sized the mounting holes for an M3 brass insert. If you shrink them before printing, you might be able to drill and tap the holes, or you could just use a nut, or a sheet-metal screw... the sky's the limit, really. Watch this space for photos of the inserts (which I plan to install with a soldering iron).